package com.mad3125.finalproject.data;

public class Restaturant {
    public String ref;
    public String title;
    public String desc;
    public String longitude;
    public String latitude;
    public String img1;
    public String img2;
    public String img3;
    public String by;
}
