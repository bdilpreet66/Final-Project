package com.mad3125.finalproject.data;

public class Comment {
    public String ref;
    public String desc;
    public String rating;
    public String by;
}
